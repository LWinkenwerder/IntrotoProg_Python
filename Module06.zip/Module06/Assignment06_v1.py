#-------------------------------------------------#
# Title:    Working with Functions
# Dev:      Lwinkenwerder
# Date:     May 06, 2019
# ChangeLog:
#   RRoot, 11/02/2016, Created starting template
#   Lwinkenwerder, 04/28/2019, Added/removed code to complete assignment 5
#   Lwinkenwerder, 05/04/2019, Updated script to fix Dictionary after reviewing AF & RR scripts
#   Lwinkenwerder, 05/06/2019, Updated with functions
#-------------------------------------------------#

#-- Section 1. Data---#

obj_new_file = None #sourcefile
strData = None #a row of string data from the source file
dicTable = None #dictionary
strMenu = None #menu options
strChoice = None #user menu choice input
lstTable = None #result of processing

#--Section 2. Processing ---#
#  Create a Class to hold this list of functions

class ToDoListProcessor(object):
    """This class holds the list of functions in this program"""

    @staticmethod
    def load_data():
        """When the program starts, this function loads each "row" of data in "ToDo.txt" into a python Dictionary."""
        obj_new_file = open("ToDo.txt","r")
        for row in obj_new_file: #run data file through a loop
            dicTable = {} #initialize dictionary to empty at start of every loop
            dicTable["Task"] = row.split(",")[0].rstrip() #create Key & Value; split data at ',' character; strip new lines
            dicTable["Priority"] = row.split(",")[1].rstrip() #create Key & Value; split data at ',' character; strip new lines
            lstTable.append(dicTable) #append new dictionary values to the master list table
        obj_new_file.close()
        return

    @staticmethod
    def display_menu():
        """This function displays a menu of choices to the user"""
        print ("""
        Menu of Options
        1) Show current data
        2) Add a new item.
        3) Remove an existing item.
        4) Save Data to File
        5) Exit Program
        """)
        return

    @staticmethod
    def list_items():
        """This function displays the contents of the ToDo list"""
        lstTable = []
        strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
        if strChoice.strip() == '1':
            print("\n These are the items currently in the To Do List")
        for row in lstTable:  # for the rows in the master list table
            print(str(row))  # prints each row out as a string
        return

    @staticmethod
    def new_item():
        """This function adds a new item to the ToDo list"""
        strChoice = ""
        dicTable = {}
        lstTable = []
        while True:
            print ("""
            Menu of Options
            1) Show current data
            2) Add a new item.
            3) Remove an existing item.
            4) Save Data to File
            5) Exit Program
            """)
            strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
            if (strChoice.strip() == '2'):
                task = input("Please enter a new task:")  # user inputs a new task
                priority = input("Please enter a task priority (low/high:")  # user inputs a new priority
                dicTable = {"Task": task, "Priority": priority}  # Creates the new Key:Value pair w/the user inputted data
                lstTable.append(dicTable)  # appends the master table with the new dictionary Key:Value pair
                print(lstTable)  # display appended list
        return

    @staticmethod
    def remove_item():
        """This function removes an item from the ToDo list"""
        lstTable = []
        while True:
            print ("""
            Menu of Options
            1) Show current data
            2) Add a new item.
            3) Remove an existing item.
            4) Save Data to File
            5) Exit Program
            """)
            strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
            if(strChoice == '3'):
                try:
                    print(lstTable)
                    delValue = input("Look at the list above, then depending on which item you want to delete, enter a number starting at 0(first item),1(second item, 3(third item), and so on:")
                    del lstTable[int(delValue)]
                    print("Now check to see how your list looks - did you remove the right item?")
                    print(lstTable)
                except:
                    print("Whoops, no such item exists - try a new number until it works")
        return

    @staticmethod
    def save_tasks():
        """This function saves data to the ToDo list"""
        lstTable = []
        dicTable = {}
        obj_new_file = "ToDo.txt"
        while True:
            print ("""
            Menu of Options
            1) Show current data
            2) Add a new item.
            3) Remove an existing item.
            4) Save Data to File
            5) Exit Program
            """)
            strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
            if (strChoice.strip() == '4'):
                if ("y" == str(input("Save this data to file? (y/n) - ")).strip().lower()):
                    obj_new_file = open(obj_new_file, "w")
                for dicTable in lstTable:
                    obj_new_file.write(dicTable["Task"] + "," + dicTable["Priority"] + "\n")
                    obj_new_file.close()
                else:
                    input("New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.")
            return

    @staticprogram
    def exit_program(self):
        """This function exits the program"""
        while True:
            print ("""
                Menu of Options
                1) Show current data
                2) Add a new item.
                3) Remove an existing item.
                4) Save Data to File
                5) Exit Program
                """)
            strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
            if (strChoice.strip() == '5'):
                print("This will end the program now - good bye!")
                break
        return

#---Section3. I/O Presentation

while True:
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - ")).strip() #add .strip here(?)
    print()

#call the method (functions) so users can input Menu Choices and then information is outputted for each Menu Option
lstTable = ToDoListProcessor.load_data()

lstTable = ToDoListProcessor.display_menu()

lstTable = ToDoListProcessor.list_items()

lstTable = ToDoListProcessor.new_item()

lstTable = ToDoListProcessor.remove_item()

lstTable = ToDoListProcessor.save_tasks()

lstTable = ToDoListProcessor.exit_program()









