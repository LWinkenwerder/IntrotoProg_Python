#-------------------------------------------------#
# Section0. Preface Metadata
# Title:    Working with Dictionaries
# Dev:      Lwinkenwerder
# Date:     April 28, 2019
# ChangeLog:
#   RRoot, 11/02/2016, Created starting template
#   Lwinkenwerder, 04/28/2019, Added/removed code to complete assignment 5
#-------------------------------------------------#

#-- Section 1. Data - Declare Variables and Constants, Read In & Load Files  --#

NewFile = "ToDo.txt"
strData = ""
dicRow = {}
lstTable = []

# When the program starts, load each "row" of data in "ToDo.txt" into a python Dictionary.
NewFile = open("ToDo.txt","r")
strData1 = NewFile.readline()
strData2 = NewFile.readline()
NewFile.close()

#Create dictionary
dicRow1 = {strData1}
dicRow2 = {strData2}

# Add each dictionary "row" to a python list "table"
lstTable = [dicRow1, dicRow2]
print(lstTable)

# Display a menu of choices to the user
while True:
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))

    # Choice 1. Show the current items in the table
    if (strChoice.strip() == '1'):
        print("\n These are the items currently in the To Do List")
        for objRow in lstTable:
            print(objRow)
        continue

    # Choice 2. Add a new item to the To Do list
    elif(strChoice.strip() == '2'):
        lstTable.append(input("Please add a Task and Priority to the To Do List ('Task, Priority(Low/High)'):"))
        print(lstTable) #display appended list
        continue

    # Choice 3. Remove an item from the To Do list
    elif(strChoice == '3'):
        try:
            print(lstTable)
            delValue = input("Look at the list above, then depending on which item you want to delete, enter a number starting at 0(first item),1(second item, 3(third item), and so on:")
            del lstTable[int(delValue)]
            print("Now check to see how your list looks - did you remove the right item?")
            print(lstTable)
        except:
            print("Whoops, no such item exists - try a new number until it works")
        continue

    #  Choice 4. Save the updated list to the ToDo.txt file
    elif(strChoice == '4'):
        NewFile = open("ToDo.txt","a")
        NewFile.write(str(lstTable))
        NewFile.close()
        print("The following list was saved to your To Do list:\n\r",lstTable)
        continue

    # Choice 5. End the program and exit
    elif (strChoice == '5'):
         print("This ends the program")
         break


