#-------------------------------------------------#
# Section0. Preface Metadata
# Title:    Working with Dictionaries
# Dev:      Lwinkenwerder
# Date:     April 28, 2019
# ChangeLog:
#   RRoot, 11/02/2016, Created starting template
#   Lwinkenwerder, 04/28/2019, Added/removed code to complete assignment 5
#   Lwinkenwerder, 05/04/2019, Updated script to fix Dictionary after reviewing TA & RR scripts
#-------------------------------------------------#

#-- Section 1. Data - Declare Variables and Constants

obj_new_file = open("ToDo.txt", "r")
strData = "" #a row of string data from the source file
lstTable = [] #master list table
#menu of user choices
strMenu = """       
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """

strChoice = "" #user menu choice input; initialize to empty at start

# Section 2. Processing
# When the program starts, load each "row" of data in "ToDo.txt" into a python Dictionary.
for row in obj_new_file: #run data file through a loop
    dicTable = {} #initialize dictionary to empty at start of every loop
    dicTable["Task"] = row.split(",")[0].rstrip() #create Key & Value; split data at ',' character; strip new lines
    dicTable["Priority"] = row.split(",")[1].rstrip() #create Key & Value; split data at ',' character; strip new lines
    lstTable.append(dicTable) #append new dictionary values to the master list table
obj_new_file.close()

# Display a menu of choices to the user
while True:
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - ")).strip() #add .strip here(?)
    print()

    # Choice 1. Show the current items in the table
    if (strChoice.strip() == '1'):
        print("\n These are the items currently in the To Do List")
        for row in lstTable: #for the rows in the master list table
            print(str(row)) #prints each row out as a string
        continue #continue will display menu again bc While True == True

    # Choice 2. Add a new item to the To Do list
    elif(strChoice.strip() == '2'):
        task = input("Please enter a new task:") #user inputs a new task
        priority = input("Please enter a task priority (low/high:") #user inputs a new priority
        dicTable = {"Task": task, "Priority": priority} #Creates the new Key:Value pair w/the user inputted data
        lstTable.append(dicTable) #appends the master table with the new dictionary Key:Value pair
        print(lstTable) #display appended list
        continue

    # Choice 3. Remove an item from the To Do list
    elif(strChoice == '3'):
        try:
            print(lstTable)
            delValue = input("Look at the list above, then depending on which item you want to delete, enter a number starting at 0(first item),1(second item, 3(third item), and so on:")
            del lstTable[int(delValue)]
            print("Now check to see how your list looks - did you remove the right item?")
            print(lstTable)
        except:
            print("Whoops, no such item exists - try a new number until it works")
        continue

    #  Choice 4. Utilized Randal's Updated Code to Overwrite Text File Data
    elif(strChoice == '4'):
        if ("y" == str(input("Save this data to file? (y/n) - ")).strip().lower()):
            objFile = open(objFileName, "w")
            for dicRow in lstTable:
                objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
            objFile.close()
            input("Data saved to file! Press the [Enter] key to return to menu.")
        else:
            input("New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.")
        continue  # to show the menu

    # Choice 5. End the program and exit
    elif (strChoice == '5'):
         print("This ends the program")
         break


